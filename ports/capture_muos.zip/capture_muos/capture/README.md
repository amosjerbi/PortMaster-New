# Capture for muOS

Screen capture port for muOS:
- Screenshot capture
- Short recording capture (APNG)
- Background hotkey daemon

## Install

1. Copy your capture zip to a computer.
2. Open the SD card.
3. Extract the zip into:
   - `ROMS/Ports/`
4. Confirm these paths exist:
   - `ROMS/Ports/capture.sh`
   - `ROMS/Ports/capture/`
5. Boot muOS and launch:
   - `Explore -> Ports -> capture`

## How To Use

From the Capture app menu:
- `Screenshot Hotkey`: enables background screenshot capture
- `Record 5s/10s/30s Hotkey`: enables background recording capture
- `Disable Hotkey`: stops the background daemon

After enabling hotkey mode, use:
- `SELECT + START` during gameplay to trigger capture

## Save Location

Both screenshots and recordings are saved to:
- `/mnt/mmc/muos/screenshot/`

Files:
- Screenshot: `screenshot_YYYYMMDD_HHMMSS.png`
- Recording (APNG): `recording_YYYYMMDD_HHMMSS.png`
- Recording frames folder: `recording_YYYYMMDD_HHMMSS/`

## CLI (Optional)

From SSH:

```bash
cd /mnt/mmc/ROMS/Ports
./capture.sh screenshot
./capture.sh record 10 10
```

Hotkey daemon:

```bash
python3 /mnt/mmc/ROMS/Ports/capture/hotkey_daemon.py start screenshot
python3 /mnt/mmc/ROMS/Ports/capture/hotkey_daemon.py start record 10
python3 /mnt/mmc/ROMS/Ports/capture/hotkey_daemon.py status
python3 /mnt/mmc/ROMS/Ports/capture/hotkey_daemon.py stop
```

## Troubleshooting

- No captures created:
  - Check daemon status:
    - `python3 /mnt/mmc/ROMS/Ports/capture/hotkey_daemon.py status`
  - Check log:
    - `cat /tmp/capture_hotkey.log`
- If hotkey does not trigger in a game:
  - Re-enable from Capture app (`Disable Hotkey`, then enable again).
