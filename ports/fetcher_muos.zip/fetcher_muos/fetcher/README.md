# Fetcher for muOS

## Install (No SSH Required)

On muOS, PortMaster may not show an `Install/Import` button.  
Use manual install by copying files to the `Ports` folder.

1. Put `fetcher.zip` on your computer.
2. Open your SD card.
3. Extract `fetcher.zip` directly into:
   - `ROMS/Ports/`
4. After extraction, confirm these paths exist:
   - `ROMS/Ports/fetcher.sh`
   - `ROMS/Ports/fetcher/`
5. Safely eject the SD card and boot muOS.
6. Launch from:
   - `Explore -> Ports -> fetcher`

## If It Does Not Appear

1. Reboot muOS once.
2. Re-check the paths above.
3. Make sure you did not end up with a nested folder like:
   - `ROMS/Ports/fetcher.zip/fetcher/...` (wrong)

