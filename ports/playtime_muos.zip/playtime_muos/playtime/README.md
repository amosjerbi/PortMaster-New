# Playtime for muOS

Playtime viewer port for muOS.  
It scans your ROM folders and shows estimated playtime for selected games using open datasets.

## Features

- Dynamic ROM indexing from muOS ROM folders
- Platform + ROM browser UI (LÖVE)
- Playtime lookup using PlayMyData + HLTB scraped data
- Cached index and lookup results for faster repeat use

## Install

1. Extract the package into:
   - `ROMS/Ports/`
2. Confirm:
   - `ROMS/Ports/playtime.sh`
   - `ROMS/Ports/playtime/`
3. Launch from:
   - `Explore -> Ports -> playtime`

## Controls

- Platform list:
  - `A`: open ROMs
  - `R2`: clear cached total + refresh platforms
  - `Start`: exit
- ROM list:
  - `A`: lookup playtime for selected ROM
  - `X`: search
  - `Y`: clear search
  - `L1/R1`: skip 10 items
  - `B`: back
  - `Start`: exit
- Playtime screen:
  - `B`: back
  - `Start`: exit

## ROM Paths

`rom_index.py` checks these in order:

1. `PLAYTIME_ROMS_DIR` (if set)
2. `/mnt/mmc/ROMS`
3. `/storage/roms` (fallback)

## CLI (Optional)

From SSH:

```bash
cd /mnt/mmc/ROMS/Ports/playtime
python3 rom_index.py --platforms
python3 rom_index.py --files "Game Boy"
python3 playtime.py --playtime "Game Boy" "Tetris.zip"
```

## Cache Files

- ROM index: `/tmp/file_cache/rom_index.json`
- Playtime lookup cache: `/tmp/file_cache/playtime_lookup_cache.json`

## Notes

- Hidden files like `._*` are ignored.
- Unsupported platforms may still appear in the list, but playtime lookup is only returned for supported platform mappings.
